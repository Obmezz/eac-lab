package EADLAB;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class BookRegistrationServlet extends HttpServlet {

    private BookDAO bookDAO;

    public BookRegistrationServlet(BookDAO bookDAO) {
        this.bookDAO = bookDAO;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title = request.getParameter("title");
        String author = request.getParameter("author");
        double price = Double.parseDouble(request.getParameter("price"));

        Book book = new Book(title, author, price);
        boolean result = bookDAO.addBook(book);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (result) {
            out.println("<h3>Book registered successfully!</h3>");
        } else {
            out.println("<h3>Failed to register book.</h3>");
        }
    }
}
